tag @p[distance=..5, gamemode=adventure] remove BingoTimerTick
return 1