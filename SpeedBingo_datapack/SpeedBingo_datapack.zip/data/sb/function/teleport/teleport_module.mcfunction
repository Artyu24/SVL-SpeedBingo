# Si il n'y a aucun joueur de present
execute positioned ~ ~1 ~ unless entity @a[gamemode=adventure,distance=..1] run return fail

# Si le joueur n'est pas de la bonne equipe
$execute positioned ~ ~1 ~ if entity @p[gamemode=adventure,team=!$(teamName),distance=..1] run title @p[gamemode=adventure,team=!$(teamName),distance=..2] actionbar {"text":"Tu n'est pas de la bonne équipe","color":"red"} 
$execute positioned ~ ~1 ~ if entity @p[gamemode=adventure,team=!$(teamName),distance=..1] run return fail

# Si le joueur a deja jouer
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=$(gameTag)] run title @p[distance=..2,tag=$(gameTag)] actionbar {"text":"Tu as déjà fait ce jeu !","color":"red"} 
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=$(gameTag)] run return fail

# Si le joueur n'a pas jouer le jeu

# Preparation a la tp
$execute positioned ~ ~1 ~ run tag @a[team=$(teamName),distance=..2] remove BingoTPPad
$execute positioned ~ ~1 ~ run tag @p[team=$(teamName),distance=..1] add BingoTPPad
$execute positioned ~ ~1 ~ run scoreboard players reset @a[team=$(teamName),distance=..2,tag=!BingoTPPad] BingoTP
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..2,tag=!BingoTPPad] run return fail
$execute positioned ~ ~1 ~ run scoreboard players add @p[team=$(teamName),distance=..1,tag=BingoTPPad] BingoTP 1

# Visuel
$execute positioned ~ ~1 ~ as @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=1}] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.5
$execute positioned ~ ~1 ~ as @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=1..39}] at @s run particle minecraft:reverse_portal ~ ~0.2 ~ 0.35 0.15 0.35 0.08 8 force 

# Textuel
$execute positioned ~ ~1 ~ run title @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=1..10}] actionbar {"text":"Téléportation  ■□□□","color":"aqua"}
$execute positioned ~ ~1 ~ run title @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=11..20}] actionbar {"text":"Téléportation  ■■□□","color":"aqua"}
$execute positioned ~ ~1 ~ run title @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=21..30}] actionbar {"text":"Téléportation  ■■■□","color":"aqua"}
$execute positioned ~ ~1 ~ run title @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=31..40}] actionbar {"text":"Téléportation  ■■■■","color":"aqua"}
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=..39}] run return fail

# Moment de la TP
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=BingoTPPad,scores={BingoTP=40..}] run tag @p[team=$(teamName),distance=..1,tag=BingoTPPad] add $(gamePlayTag)
$function sb:head_feedback/head_add_team {teamTag:"$(teamName)", newHeadTag:"$(newHeadTag)", moveX:"$(moveX)", returnMoveX:"$(returnMoveX)"}
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=$(gamePlayTag),tag=BingoTPPad] run scoreboard players reset @p[team=$(teamName),distance=..1,tag=$(gamePlayTag),tag=BingoTPPad] BingoTP
$execute positioned ~ ~1 ~ if entity @p[team=$(teamName),distance=..1,tag=$(gamePlayTag),tag=BingoTPPad] run tp @p[team=$(teamName),distance=..1,tag=$(gamePlayTag),tag=BingoTPPad] $(tpCoord)
$execute as @a[team=$(teamName),distance=5..100,tag=$(gamePlayTag),tag=BingoTPPad] run tag @s remove BingoTPPad
return 1